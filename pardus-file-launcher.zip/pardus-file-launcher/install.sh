#!/usr/bin/env bash
# Pardus File Launcher - Otomatik Kurulum Scripti
# Bu script; gerekli paketleri kontrol eder, script dosyasini yerlestirir
# ve Thunar'a otomatik olarak sag-tik ozel eylemini ekler.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_FILE="$SCRIPT_DIR/File Launcher V2.4 (for Pardus).py"
INSTALL_DIR="$HOME/.local/bin"
TARGET_FILE="$INSTALL_DIR/pardus-file-launcher.py"
UCA_FILE="$HOME/.config/Thunar/uca.xml"

echo "== Pardus File Launcher Kurulumu =="

if [ ! -f "$SOURCE_FILE" ]; then
    echo "Hata: '$SOURCE_FILE' bulunamadi. Bu scripti proje klasorunun icinden calistirin."
    exit 1
fi

# 1) i386 mimarisi kontrolu (Wine 32-bit icin gerekli)
if ! dpkg --print-foreign-architectures | grep -q i386; then
    echo "i386 mimarisi etkin degil."
    read -p "i386 mimarisini simdi etkinlestirmek istiyor musunuz? [E/h] " answer
    if [[ "$answer" =~ ^[Ee]$ || -z "$answer" ]]; then
        sudo dpkg --add-architecture i386
        sudo apt update
    fi
fi

# 2) Zorunlu paketleri kontrol et
REQUIRED_PKGS=("wine" "wine32:i386" "python3-tk")
OPTIONAL_PKGS=("default-jre" "xarchiver")
MISSING=()

for pkg in "${REQUIRED_PKGS[@]}"; do
    if ! dpkg -s "$pkg" >/dev/null 2>&1; then
        MISSING+=("$pkg")
    fi
done

if [ ${#MISSING[@]} -gt 0 ]; then
    echo "Eksik zorunlu paketler: ${MISSING[*]}"
    read -p "Bu paketleri simdi kurmak istiyor musunuz? [E/h] " answer
    if [[ "$answer" =~ ^[Ee]$ || -z "$answer" ]]; then
        sudo apt install -y "${MISSING[@]}"
    else
        echo "Uyari: Eksik paketler olmadan program duzgun calismayabilir."
    fi
fi

for pkg in "${OPTIONAL_PKGS[@]}"; do
    if ! dpkg -s "$pkg" >/dev/null 2>&1; then
        echo "Bilgi: Opsiyonel paket '$pkg' kurulu degil (.jar veya .zip destegi icin gerekebilir)."
    fi
done

# 3) Script dosyasini kalici bir konuma yerlestir
mkdir -p "$INSTALL_DIR"
cp "$SOURCE_FILE" "$TARGET_FILE"
chmod +x "$TARGET_FILE"
echo "Script su konuma kopyalandi: $TARGET_FILE"

# 4) Thunar ozel eylemini guvenli sekilde (mevcut eylemleri bozmadan) ekle
python3 - "$UCA_FILE" "$TARGET_FILE" << 'PYEOF'
import sys
import os
import xml.etree.ElementTree as ET

uca_path, target_file = sys.argv[1], sys.argv[2]
os.makedirs(os.path.dirname(uca_path), exist_ok=True)

command = 'python3 "{}" %f'.format(target_file)

if os.path.isfile(uca_path):
    tree = ET.parse(uca_path)
    root = tree.getroot()
else:
    root = ET.Element("actions")
    tree = ET.ElementTree(root)

exists = False
for action in root.findall("action"):
    cmd_el = action.find("command")
    if cmd_el is not None and cmd_el.text == command:
        exists = True
        break

if not exists:
    action = ET.SubElement(root, "action")
    ET.SubElement(action, "icon").text = "utilities-terminal"
    ET.SubElement(action, "name").text = "File Launcher ile Ac"
    ET.SubElement(action, "unique-id").text = "pardus-file-launcher-001"
    ET.SubElement(action, "command").text = command
    ET.SubElement(action, "description").text = "exe/jar/zip dosyalarini File Launcher ile calistir"
    ET.SubElement(action, "patterns").text = "*.exe;*.jar;*.zip"
    ET.SubElement(action, "other-files").text = "true"
    tree.write(uca_path, encoding="UTF-8", xml_declaration=True)
    print("Thunar ozel eylemi eklendi.")
else:
    print("Thunar ozel eylemi zaten mevcut, tekrar eklenmedi.")
PYEOF

echo ""
echo "Kurulum tamamlandi."
echo "Thunar'i yeniden baslatmaniz gerekebilir: thunar -q ; thunar &"
