#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File Launcher V2.4 (for Pardus)
---------------------------------
Pardus (Debian tabanli XFCE) icin basit dosya baslatici.

Kullanim:
    python3 "File Launcher V2.4 (for Pardus).py" /yol/dosya.exe

Desteklenen uzantilar:
    .exe -> wine ile calistirilir
    .jar -> java -jar ile calistirilir
    .zip -> sistemin varsayilan arsiv yoneticisi ile acilir
"""

import os
import sys
import shutil
import subprocess
import threading
import tkinter as tk
from tkinter import messagebox


APP_TITLE = "File Launcher V2.4 (for Pardus)"


def find_command(candidates):
    """Verilen komut adaylarindan sistemde kurulu olan ilk komutun
    tam yolunu dondurur. Hicbiri bulunamazsa None doner."""
    for name in candidates:
        path = shutil.which(name)
        if path:
            return path
    return None


def build_command(file_path):
    """Dosya uzantisina gore calistirilacak komutu (liste halinde) dondurur."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".exe":
        wine_cmd = find_command(["wine"])
        if not wine_cmd:
            raise RuntimeError("Wine sistemde bulunamadi. Kurmak icin: sudo apt install wine")
        return [wine_cmd, file_path]

    if ext == ".jar":
        java_cmd = find_command(["java"])
        if not java_cmd:
            raise RuntimeError("Java sistemde bulunamadi. Kurmak icin: sudo apt install default-jre")
        return [java_cmd, "-jar", file_path]

    if ext == ".zip":
        archive_cmd = find_command(["xarchiver", "file-roller", "engrampa", "xdg-open"])
        if not archive_cmd:
            raise RuntimeError("Bir arsiv yoneticisi bulunamadi.")
        return [archive_cmd, file_path]

    raise RuntimeError("Desteklenmeyen dosya turu: " + ext)


class LauncherWindow:
    def __init__(self, root, file_path):
        self.root = root
        self.file_path = file_path

        self.root.title(APP_TITLE)
        self.root.geometry("380x150")
        self.root.resizable(False, False)

        self.label = tk.Label(
            root,
            text="Baslatiliyor...\n" + os.path.basename(file_path) + "\n\nDeveloped by Yusuf Gültekin",
            font=("Sans", 11),
            pady=15,
        )
        self.label.pack(expand=True)

        self.close_button = tk.Button(root, text="Kapat", command=root.destroy)
        self.close_button.pack(pady=10)
        self.close_button.pack_forget()  # basta gizli, sadece hata olursa gosterilir

        self.root.after(200, self.start_launch)

    def start_launch(self):
        thread = threading.Thread(target=self.launch, daemon=True)
        thread.start()

    def launch(self):
        try:
            command = build_command(self.file_path)
            work_dir = os.path.dirname(self.file_path) or "."
            subprocess.Popen(command, cwd=work_dir)
            self.root.after(0, self.on_success)
        except Exception as error:
            self.root.after(0, lambda: self.on_error(str(error)))

    def on_success(self):
        self.label.config(text=os.path.basename(self.file_path) + "\nbaslatildi.")
        self.root.after(1200, self.root.destroy)

    def on_error(self, message):
        self.label.config(text="Hata olustu:")
        messagebox.showerror(APP_TITLE, message)
        self.close_button.pack(pady=10)


def main():
    if len(sys.argv) < 2:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            APP_TITLE,
            "Bir dosya yolu belirtilmedi.\nKullanim: File Launcher V2.4 (for Pardus).py <dosya>",
        )
        return

    file_path = sys.argv[1]

    if not os.path.isfile(file_path):
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_TITLE, "Dosya bulunamadi:\n" + file_path)
        return

    root = tk.Tk()
    LauncherWindow(root, file_path)
    root.mainloop()


if __name__ == "__main__":
    main()
