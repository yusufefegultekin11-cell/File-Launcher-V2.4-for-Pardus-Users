# File Launcher V2.4 (for Pardus)

Pardus (Debian tabanlı XFCE) üzerinde `.exe`, `.jar` ve `.zip` dosyalarını Thunar dosya yöneticisinde sağ tık menüsünden tek tıkla çalıştırmayı sağlayan basit bir Python + Tkinter aracı.

## Özellikler

- `.exe` dosyalarını **Wine** ile çalıştırır
- `.jar` dosyalarını **Java** ile çalıştırır
- `.zip` dosyalarını sistemin varsayılan arşiv yöneticisiyle açar
- Thunar sağ tık menüsüne özel eylem olarak entegre olur
- Başlatma sırasında basit bir "Başlatılıyor..." arayüzü gösterir
- Hata durumunda kullanıcıya açıklayıcı bir mesaj kutusu gösterir

## Gereksinimler

| Paket | Amaç | Zorunlu mu? |
|---|---|---|
| `python3`, `python3-tk` | Arayüz | Evet |
| `wine` + `wine32:i386` (i386 mimarisi etkin) | `.exe` desteği | Evet (exe kullanılacaksa) |
| `default-jre` | `.jar` desteği | Hayır (opsiyonel) |
| `xarchiver` / `file-roller` / `engrampa` | `.zip` desteği | Hayır (opsiyonel) |

## Kurulum

### Otomatik kurulum (önerilen)

```bash
git clone https://github.com/KULLANICI_ADI/pardus-file-launcher.git
cd pardus-file-launcher
chmod +x install.sh
./install.sh
```

`install.sh` şunları yapar:
1. i386 mimarisinin etkin olup olmadığını kontrol eder, değilse onayınızla etkinleştirir.
2. Eksik paketleri (`wine`, `wine32:i386`, `python3-tk`) tespit edip onayınızla kurar.
3. Script'i `~/.local/bin/pardus-file-launcher.py` konumuna yerleştirir.
4. Thunar'ın özel eylemler dosyasına (`~/.config/Thunar/uca.xml`) otomatik olarak "File Launcher ile Aç" eylemini ekler (mevcut eylemlerinizi silmez, sadece yoksa ekler).

Kurulumdan sonra Thunar'ı yeniden başlatmanız gerekebilir:
```bash
thunar -q ; thunar &
```

### Manuel kurulum

1. `File Launcher V2.4 (for Pardus).py` dosyasını istediğiniz bir klasöre kopyalayın.
2. Thunar'da **Düzenle → Özel Eylemleri Yapılandır... → +**
   - **Ad:** `File Launcher ile Aç`
   - **Komut:** `python3 "/tam/yol/File Launcher V2.4 (for Pardus).py" %f`
   - **Görünüm Koşulları** sekmesi → Dosya Deseni: `*.exe;*.jar;*.zip`, "Diğer Dosyalar" işaretli
3. Kaydedin. Artık desteklenen dosyalara sağ tıkladığınızda eylem menüde görünecektir.

## Kullanım

Elle test etmek isterseniz:

```bash
python3 "File Launcher V2.4 (for Pardus).py" "/yol/dosya.exe"
```

## Bilinen Sorunlar / Sorun Giderme

**`wine: could not load kernel32.dll, status c0000135`**
Wine prefix'iniz (`~/.wine`) bozuk veya yanlış mimaride (win64) oluşturulmuş olabilir. Temiz bir 32-bit prefix oluşturmak için:
```bash
mv ~/.wine ~/.wine-eski
WINEARCH=win32 winecfg
```

**Bir `.exe` çalıştırdığımda program yerine bir kurulum sihirbazı veya HTML sayfası açılıyor**
Bu bir hata değildir — bazı `.exe` dosyaları doğrudan program değil, kurulum paketi (installer) olabilir. Davranış tamamen dosyanın kendisine bağlıdır.

**Sağ tık menüsünde eylem görünmüyor**
Thunar'ın özel eylemler penceresinde "Görünüm Koşulları" sekmesindeki dosya deseninin (`*.exe;*.jar;*.zip`) doğru girildiğinden ve "Diğer Dosyalar" kutucuğunun işaretli olduğundan emin olun.

## Katkıda Bulunma

Hata bildirimleri ve iyileştirme önerileri için Issues sekmesini kullanabilirsiniz.

## Lisans

MIT — ayrıntılar için [LICENSE](LICENSE) dosyasına bakın.
